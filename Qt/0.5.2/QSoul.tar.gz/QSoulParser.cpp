#include "QSoulParser.h"

QSoulParser::QSoulParser(QObject *parent) : QObject(parent){
}
